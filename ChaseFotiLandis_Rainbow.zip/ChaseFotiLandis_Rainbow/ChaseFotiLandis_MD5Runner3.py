#Checks files that are hashed against a rainbow table!

import os
import subprocess
from datetime import datetime

#Variables for when choosing whether or not to agree.
options = ['Yes','y','yes','No','no','n']
noOptions= ['No','no','n']
yesOptions = ['Yes','y','yes']
rightNow=str(datetime.now())

os.system("clear")

#Greets the user.
def greeting():
	#Says hello and then time stamps.
	print('\t\tWelcome to the MOST secure server in the world!!!')
	print('\n \t\tThe time is ' + rightNow + '\n')

#Function that checks whether or not the person agrees to working ethically.
def toAgree():
	agreement = raw_input("Do you agree to use this program ethically?  Please type y/n: ")
	#If they write anything that doesn't resemble yes or no, it will keep them here.
	while agreement not in options:
		agreement = raw_input('Please write either "Yes" or "No": ')
	#If they say no, then end the program.
	if agreement in noOptions:
		print("\nIf you cannot use this program ethically, then we have nothing left to discuss.\n" + 'Goodbye\n')
		quit()
	if agreement in yesOptions:
		print('\n \t\tOh good.  Im glad to hear you are ethical! \n')
		#Writes default files so we don't have to memorize them.
		return True

#Function that will check the rainbow table with the shadowlist for matches.

def rainbowCheck():
	#Lets the user choose their shadow file, rainbow table, and the name of their output file.
	print('\nDefault files to use: "ChaseFotiLandis_ShadowList.txt","ChaseFotiLandis_RainbowTable.txt","ChaseFotiLandis_Output.txt",\n')
	print("This program ONLY uses '.txt' files.\n")


	shadowFile = raw_input("Please write the shadow file that you want to check: ")
	rainbowFile = raw_input("Please write the rainbow table you would like to use: ")
	outputFile = raw_input("Please name the file you want to save the passwords that match both files: ")

	#Checks if the file exists and if it does, appends it.  If the file doesn't exist, it creates it.
	try:
		open(outputFile)
	except:
		a = 'w+'
	else:
		a = 'a'

	#Creates or appends the output file.
	output = open(outputFile, a)

	#Takes each line of the shadow list and creates the variable to check in the rainbow table.
	with open(shadowFile, 'r') as f:
		queries=[l.strip()for l in f]

	#Time stamp
	output.write('\nStarted at ' + rightNow + '\n')


	

	#Function to check the rainbow table of the contents of the shadow list.
	with open(rainbowFile, 'r') as f:
		#checks each line in the rainbow file
		for line in f:
			#checks each line in the shadow list
			for query in queries:
				#Checks if the lines match, and writes into the file the passwords that do match.
				if query in line:
					print('\nThe password, ' + line + 'has been matched with the rainbow table \n')
					output.write(query + line + '\n')
					output.flush()
	#Ending time stamp written at the end of the output file.
	output.write('\nEnded at ' + rightNow + '\n')

	output.close()

	oneMoreTime()

def oneMoreTime():
	anotherOne = raw_input('If you would like to perform the function on another file, please type "yes" or "no" : ')
	
	while anotherOne not in options:
		anotherOne = raw_input('Please write either "Yes" or "No": ')
	if anotherOne in noOptions:
		print('\nThank you for using MD5 runner, Chase edition.  Make sure to check your files to see if it worked correctly!\n')
		print('Good-bye!')
	elif anotherOne in yesOptions:
		rainbowCheck()

greeting()
toAgree()
rainbowCheck()


	




