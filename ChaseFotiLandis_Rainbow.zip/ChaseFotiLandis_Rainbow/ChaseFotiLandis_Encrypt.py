#Converts a file of passwords into a Rainbow Table.
#There is already a rainbow table defined - ChaseFotiLandis

from datetime import datetime

from hashlib import md5 
import sys
import os


def greeting():
	print("Welcome to Chase's Rainbow table creator!  The time is: \n" + rightNow + '\n')
	print('\tYou are here to encrypt to MD5, correct?')

def makeItHash():
	#checks every line in the file that give
	for line in iter(openInput):
		#Takes every line and encrypts it into an MD5 hash
		product = md5(line.strip().encode('utf-8')).hexdigest()
		#writes the password and the hashed password into the new output file.
		hashFile.write(product + "----" + line)
		print('Hashing now... \n')
	hashFile.write('\n' + rightNow)

os.system("clear")

rightNow=str(datetime.now())

#Asks for list of passwords to be encrypted.
print('The default file is ChaseFotiLandis_PSwd.txt')
inputFile = raw_input('Please enter the file you want to encrypt to MD5: ')

openInput = open(inputFile)
#Rainbow table I use to encode the passwords.
hashFile = open("ChaseFotiLandis_RainbowTable.txt", 'w+')

greeting()
makeItHash()

hashFile.close()
print('\n Done!  Please double check the file that you have encrypted \n')

print('The time now is ' +rightNow+ '\n')

